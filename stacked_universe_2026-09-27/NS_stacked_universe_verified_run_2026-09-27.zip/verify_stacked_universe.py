"""Reimplementation of saved model equations, not original historical generator."""
from pathlib import Path
import numpy as np
import json, hashlib, subprocess
p=Path(__file__).resolve().parent
f=p/'stacked_universe_toy_simulation_v2.csv'
d=np.genfromtxt(f,delimiter=',',names=True)
t=d['time']; s=d['stacked_time_field']; e=d['energy_inflow']; dt=float(np.median(np.diff(t)))
k=6.090376005484056e-3

def downstream(s):
 x=np.empty(len(s)); r=np.zeros(len(s)); x[0]=d['space_scale_proxy'][0]
 for i in range(1,len(s)):
  x[i]=x[i-1]+k*max(s[i]-2.45,0)*dt
  r[i]=r[i-1]+.03*max(s[i]-4.75,0)*dt
 g=np.gradient(s,t)
 return x,r,g+.16*r,g

def err(a,b):
 v=a-b
 return {'rms':float(np.sqrt(np.mean(v*v))),'max_abs':float(np.max(np.abs(v)))}
x,r,fp,g=downstream(s)
sr=np.zeros(len(s));sr[0]=s[0]
for i in range(1,len(s)):
 u=(sr[i-1]+dt*e[i])/(1+.004*dt)
 sr[i]=u if u<=2.45 else (sr[i-1]+dt*(e[i]+.01*2.45))/(1+.014*dt)
xr,rr,fr,gr=downstream(sr)
# Explicitly cover inactive, boundary and active branches.
grid=np.unique(np.r_[np.linspace(0,6,1000),2.45])
b=np.maximum(grid-2.45,0); lam=b-(grid-2.45)
# Independent constrained scalar minimization of .005 B^2, B>=0 and B>=S-2.45.
from scipy.optimize import minimize_scalar
numeric=np.array([minimize_scalar(lambda z:.005*z*z,bounds=(max(0,float(v-2.45)),10),method='bounded',options={'xatol':1e-12}).x for v in grid])
transition={}
for threshold in [2.45,4.75]:
 ids=np.flatnonzero(s>=threshold)
 transition[str(threshold)]={'first_sample_time':float(t[ids[0]]),'first_sample_S':float(s[ids[0]]),'previous_sample_S':float(s[ids[0]-1])} if len(ids) else None
original=[]
for source in sorted(p.glob('NS_*.py')):
 z=subprocess.run(['python3',str(source)],capture_output=True,text=True)
 original.append({'file':source.name,'sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'exit_code':z.returncode,'stdout':z.stdout})
out={'scope':'Saved toy simulation internal reproducibility, not observational cosmology validation; coefficients copied from saved reports, no refit. Time/field units not established as physical units.','input_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'rows':len(s),'dt':dt,'saved_S_downstream':{'X':err(x,d['space_scale_proxy']),'R':err(r,d['rotation_order_proxy']),'gradient':err(g,d['stack_gradient']),'F':err(fp,d['emergent_force_proxy'])},'forward_from_E':{'S':err(sr,s),'X':err(xr,d['space_scale_proxy']),'R':err(rr,d['rotation_order_proxy']),'F':err(fr,d['emergent_force_proxy'])},'complementarity':{'samples':len(grid),'min_B':float(min(b)),'min_lambda':float(min(lam)),'max_product':float(max(abs(b*lam))),'independent_optimizer_max_error':float(max(abs(numeric-b))),'curvature_below':.004,'curvature_above':.014,'curvature_at_threshold':'second derivative undefined; one-sided values differ'},'threshold_samples':transition,'original_scripts':original,'unresolved':['exact historical S generator','residual_trace causal generator','universal Gamma identification','observational-data validation']}
(p/'verification_results.json').write_text(json.dumps(out,indent=2))
print(json.dumps({k:v for k,v in out.items() if k!='original_scripts'},indent=2))
