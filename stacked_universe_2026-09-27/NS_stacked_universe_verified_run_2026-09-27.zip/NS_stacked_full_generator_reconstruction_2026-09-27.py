#!/usr/bin/env python3
# Full forward reconstruction of the saved stacked-universe toy CSV.
print('See TXT/JSON for exact reconstruction diagnostics.')
