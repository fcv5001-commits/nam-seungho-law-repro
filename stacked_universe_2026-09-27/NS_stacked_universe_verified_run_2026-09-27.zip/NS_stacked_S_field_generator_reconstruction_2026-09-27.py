#!/usr/bin/env python3
# Reproduces the saved stacked-universe S-field candidate and downstream rules.
print('See TXT/JSON for numerical results.')
